<template>
  <div id="app">
    <!-- @click="goBack" -->
    <!-- v-show是否显示该内容 -->
    <!-- <mt-header class="top-header" fixed :title="$route.meta.title">
      <span slot="left" >

        <button icon="back" v-show="$route.meta.title==='首页'? flase:true">返回</button>
        
      </span>
    </mt-header>  -->
   
     

    <div class="nav-bottom">
      <ul>
        <!-- <li>首页</li>
        <li>分类</li>
        <li>购物车</li>
        <li>我的</li> -->
        <router-link to="/home" tag="li">
          <i class="glyphicon glyphicon-road"></i>
          <span>首页</span>
        </router-link>
          <router-link to="/firstpage" tag="li">
          <i class="glyphicon glyphicon-th-large"></i>
          <span>店内就餐</span>
        </router-link>
          <router-link to="/shopcart" tag="li">
          <i class="glyphicon glyphicon-list-alt"></i>
          <div class="counter">
              {{$store.getters["shopcart/getCount"]}}
          </div>
          <span>外卖点餐</span>
        </router-link>
          <router-link to="/my2" tag="li">
          <i class="glyphicon glyphicon-user"></i>
          <span>会员中心</span>
        </router-link>
      </ul>
    </div>
    <router-view />
  </div>
</template>

<script>
export default {
  name: "App",
  data(){
    return{
      navlist:[
        {
          name:"首页",url:"/home",icon:"glyphicon glyphicon-road"
        },
        {
          name:"店内就餐",url:"/classify",icon:"glyphicon glyphicon-th-large"
        },
        {
          name:"外卖点餐",url:"/shopcart",icon:"glyphicon glyphicon-list-alt"
        },
        {
          name:"会员中心",url:"/my",icon:"glyphicon glyphicon-user"
        }
      ]
    }
  }
  // ,
  // methods{

  // }
};
</script>

<style>
* {
  list-style: none;
  padding: 0;
  margin: 0;
  font-size: 16px;
}
/* .top-header{
  background-color: #6DA193;
} */
.counter{
  position:absolute;
  top:2px;
  right:125px;
  height:20px;
  width:20px;
  border-radius:10px;
  line-height:20px;
  background:rgb(53, 231, 62);
  color:aliceblue;
  padding-left:3px;
  border:1px solid rgb(66, 199, 14);
}
.nav-bottom {
  width: 100%;
  height: 60px;
  position: fixed;
  bottom: 0;
  z-index: 1000;
  padding-bottom: 20px;
  background: #84a378;
}
.nav-bottom ul {
  display: flex;
  height: 60px;
}
.nav-bottom ul li {
  width: 25%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
.router-link-active{
  color:#B2DFDA;
  background: #6DA193;
}
</style>
