import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/components/Login'
import Home from '@/components/Home/Home'
import Classify from '@/components/Classify/Classify'
import Shopcart from '@/components/Shopcart/Shopcart'
import Shops from '@/components/Shopcart/Shops'
import My from '@/components/My/My'
import my2 from '@/components/My/my2'
import my3 from '@/components/My/my3'
import Commodity from '@/components/Home/Commodity'
import GoodList from '@/components/GoodList.vue'
//import { Store } from 'vuex'
//import OrderCreate from '@/components/Order/OrderCreate.vue'
// import{Store}from 'vuex'
// import store from '@/store'

import firstpage from '../components/Meal/firstpage'
import placeorder from '../components/Meal/placeorder'
//import placeorder from '@/components/Meal/placeorder'


Vue.use(Router)
const router =new Router({
  routes:[
    {
      path:',',
      //name:'hello',
      
    }
  ]
})
//要直接打开能看见就要配置路由
// 路径要会手写
router.beforeEach((to,from,next)=>{
  if(to.meta.requireAuth){
    if(store.state.usern.username){
      next()
    }else{
      next({path:'/login'})
    }
  }
})



export default new Router({
  routes: [
    {
      path: '/login',
      name: 'Login',
      mata:{title:'登录'},
      component: Login
    },
    {
      path:'/Home',
     // redirect:'/home',//重定向
      meta:{title:'首页'},
      component:Home
    },
    {
      path:'/Classify',
      meta:{title:'分类'},
      component:Classify
    },
    {
      path:'/Shopcart',
      meta:{title:'购物车',requireAuth:true},//这个变量true的时候，跳转这个页面就要验证用户是登陆的
      component:Shopcart
    },
    {
      path:'/Shops',
      meta:{title:'宝可梦列表',requireAuth:true},//这个变量true的时候，跳转这个页面就要验证用户是登陆的
      component:Shops
    },
    {
      path:'/my',
      meta:{title:'我的'},
      component:My
    },
    {
      path:'/my2',
      component:my2
    },
    {
      path:'/my3',
      component:my3
    },
    {
      path:'/commodity/:id',//动态路由
      component:Commodity
    },
    {
      path:'/goodlist',
      component:GoodList
    },
    // {
    //   path:'/order/ordercreate',
    //   name:'order_create',
    //   meta:{title:'结算'},
    //   component:OrderCreate
    // },
    
    {
      path: '/firstpage',
      name: 'firstpage',
      component: firstpage
    },
    {
      path: '/placeorder',
      name: 'placeorder',
      component: placeorder
    }

  ],
  linkActiveClass:"router-active"
})
