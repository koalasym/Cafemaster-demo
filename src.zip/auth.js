import { install } from "vuex"

var auth={
    //获取
    getAuthorization(){
        return localStorage.getItem('Authorization')
    },
    //保存
    setAuthorization(Authorization){
        localStorage.setItem('Authorization',Authorization)
    }
}
//插件
export default{
    install:function(vue){
        vue.prototype.$auth=auth
    }
}
