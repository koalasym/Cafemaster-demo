// The Vue build version to load with the `import` command
// (runtime-only or standalone) has been set in webpack.base.conf with an alias.
import Vue from 'vue'
import App from './App'
import router from './router'

Vue.config.productionTip = false
import './assets/css/bootstrap.min.css'
import store from './components/store'
//引入axios
import axios from 'axios'
//Vue.prototype.$axios=axios;//this.$axios进行阿贾克斯请求和发送
//axios.defaults.baseURL='http://localhost:8080';
Vue.prototype.$http=axios;//this.$http
//引入mock.js文件,资源的引入用require
//import './lib/mui/css/mui.css'
//import './lib/mui/css/mui.min.css'

// import MintUI from 'mint-ui'
// import 'mint-ui/lib/style.css'
// Vue.use(MintUI)
import ElementUI from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
Vue.use(ElementUI)
import './index.css'

//引入mock.js文件
require('./Mock/mock.js')

import auth from './auth.js'
Vue.use(auth)

import { Toast } from 'vant'
Vue.use(Toast);

/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  components: { App },
  template: '<App/>',
  store
})
