<template>
  <div>
      <ul class="box">
          <li class="number-button">
              <button @click="substract()">-</button>
          </li>
            <li>
                <input class="input-count" type="number" value="0" size="1" v-model="count">
            </li>
            <li class="number-button">
                <button @click="add()">+</button>
            </li>
      </ul>
  </div>
</template>

<script>
export default {
    data(){
        return {
            count:0
        }
    },
    props:["num","id"],//接受传递的参数
    methods:{
        substract(){//减按钮的操作
            if(this.count<=0)
            {this.count=0;}
            else{
                this.count--;
            }
            this.$store.dispatch("shopcart/numA",{num:this.count,id:this.id})
        },
        add(){//加按钮的操作
            this.count++;
            this.$store.dispatch("shopcart/numA",{num:this.count,id:this.id})
        },
        del(context,id){
            context.commit('del',id)
        },
        numboxA(context,good){
            
        }
    },
    
    created(){
        this.count=this.num;
    }
}
</script>

<style scoped>
ul,li{
    list-style:none;
}
.box{
    display:flex
}
.box .number-button{
    width:10px;
    height:10px;
}
.box .input-count{
    text-align:center;
    height:27px;
    width:20px;
}
</style>