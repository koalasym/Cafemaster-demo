<template>
   
          <div class="recommend-content1">
            <!-- <li v-for="(item,index) in recommendlist" :key="index"> -->
              <div class="recommend-top">
                
                <img :src="data.url" alt="">
                
                <p class="recommend-details">{{data.getrecommendtext}}</p>
              </div>     
              <div class="recommend-bottom">
                <h5 class="recommend-price">{{data.price}}</h5>
                <span class="recommend-see">{{data.titletext}}</span>
              </div>
            <!-- </li> -->
         </div>
         <!-- vue axios -->
     
  
 
</template>

<script>
export default {
  data(){
      return {};
  },
 // props:["data"],//是个数组
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

/* 商品的样式 */
.recommend-content1{
  display:flex;
  flex-wrap:wrap;
  justify-items: center;
  justify-content: center;
  padding-bottom: 80px;
  padding-left: 0px;
  margin-top: 5px;
  margin-bottom: 20x;
}
.recommend-content1 {
  width:46%;
  flex-direction: column;
  padding:8px 0px;
 
}
.recommend-content1  .recommend-top img{
  width:98%;
  height:98%;
 
}
.recommend-content1  .recommend-top p{
  width:98%;
  height:98%;
  font-size: 14px;
}
.recommend-content1 .recommend-details{
  width:98%;
  height:5px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
 
}
.recommend-content1 .recommend-bottom{
  display: flex;
  height:0px;
  justify-content: space-between;
  padding:10 5px;
  margin-top: 20px;
  align-items:center;
}
.recommend-content1 .recommend-bottom .recommend-price{
  font-weight: bold;
  color:red;
  font-size: 15px;
}
.recommend-content1 .recommend-bottom .recommend-see{
  border:0.5px solid #000;
  height:21px;
  padding:2px;
  text-align:center;
  font-size:15px;
}
</style>
