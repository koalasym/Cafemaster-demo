<template>
 
    <!-- 轮播图 -->
    <div class="slide-content">
       <div class="slade-view">
          <!-- "../../assets/images/img1.jpg" -->
          <img v-for="(item,index) in slidelist"  
            :src="item" 
            :key="index" 
            alt=""  
            v-show="num===index"
          />

          <ul class="slide-page">
              <li 
                v-for="(item,index) in slidelist" 
                :key="index"
                :class="num == index ? 'active' :''">
                  <!-- num判断是不是等于index，等于就是active不等就是'' -->

              </li>
          </ul>
       </div>
    </div>
 
</template>

<script>
export default {
  name: 'slide',
  data () {
    return {
      slidelist:[
        require("../../assets/images/1.jpg"),
        require("../../assets/images/2.jpg"),
        require("../../assets/images/3.jpg"),
        require("../../assets/images/4.jpg"),
        require("../../assets/images/5.jpg")
      ],
      num:0
    };
  },
  methods:{
    go(){
      setInterval(()=>{
        this.num++;
        if(this.num==this.slidelist.length)
          this.num=0;
      },2000);
    },
  },
  created(){
    this.go();
  }
  // props:["slidelist"]//只读
  
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.slide-content .slide-view{
    height:140px;
}
.slide-content .slide-view img{
    width:92%;
    margin:0 4%;
    position:absolute;
}
.slide-content .slide-view .slide-page{
    position:relative;
    bottom:-110px;
    text-align: center;
}
.slide-content .slide-view .slide-page li{
width:10px;
height:10px;
border-radius: 10px;
background: red;
display: inline-block;
margin:0 3px;
opacity:0.6;
}
.active{
    background: #000 ;
}
</style>
