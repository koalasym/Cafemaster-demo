<template>

  <div class="list">
     <div class="home-content">
     <div class="home-top-ground"></div>
     <div class="home_nav">
      新白鹿餐厅
      <input type="text" class="home-search" v-model="searchString"/>
      <el-button @click="searchgo">搜索</el-button>
    </div>
     </div>
        <div class="item" style="margin-top:20px;">
           <div>
                  <router-link :to="{path:'/Shops'}"  tag="span" style="font-size: 30px;margin-left:34%;">我的外卖单</router-link>
          </div>
                  <div >
                       <div >
          <ul class="recommend-content">
             <router-link v-for="item in filteredArticles" :key="item.id" :to="'/commodity/'+item.id" tag="li">
              <div class="recommend-top">
                <!-- <img :src="item.url" alt=""> -->
                <img :src="require('@/assets/images/home-recommend/'+item.url+'')" alt="">
                <!-- <img :src="require('@/assets/images/home-recommend/'+" -->
                <p class="recommend-details">{{item.recommendtext}}</p>
              </div>     
              <div class="recommend-bottom">
                <h5 class="recommend-price">{{item.price}}</h5>
                <span class="recommend-see">绿色森林</span>
              </div>
            </router-link>
         </ul>
         <!-- vue axios -->
     <router-view/>
  </div>

    
          <!-- <ul class="recommend-content">
            <router-link v-for="item in recommendlist" :key="item.id" :to="'/commodity/'+item.id" tag="li">
      
              <div class="recommend-top">
                <img :src="item.url" alt="">
    
                <p class="recommend-details">{{item.recommendtext}}</p>
              </div>     
              <div class="recommend-bottom">
                <h5 class="recommend-price">{{item.price}}</h5>
                <h5 class="recommend-see">{{item.getrecommendtext}}</h5>
              </div>
            </router-link>
         </ul>  -->
         <!-- vue axios -->
     <!-- <router-view/> -->
  </div>
               
        </div>
     
        
    </div>
</template>

<script>
import item from "../Share/item.vue"
export default {
  name: 'home',
  data () {
    return {
      id:0,
      mealid:'',
      searchString:'',
      name:'pokemon',
      recommendlist:[
    
       ],
      num:0//错在这里
    }
  },
  components:{
    item//导入组件，引入子组件的第二步：注册
  },
  methods:{
    searchgo(){
      //console.log(this.recommendlist[1]);
     
    },
    getRecommendData(){
      this.$http.post("/getRecommend").then(result=>{
        console.log(result.data.data);//查看是否拿到数据
        this.recommendlist=result.data.data;
      });//then返回服务器端拿到的结果
    },
    getrecommenddb(){
      this.$http.post("http://localhost:8080/myDemos/getRecommend").then(result=>{
        console.log(result.data);
        this.recommendlist=result.data; 
      });
    },
    getrecommenddbparam(){//前端向后端传参
        this.$http.post("http://localhost:8080/myDemos/getRecommend",{params:{str:'zhangsan'}}).then(result=>{
        console.log(result.data);
        this.recommendlist=result.data;
      });
    }
    },
    created(){
      //this.getRecommendData();//静态
      this.getrecommenddb();//数据库 服务器
      //this.getrecommenddbparam();//前端向后端传值
      //this.searchgo();
    },
        computed: {
        // 计算数学，匹配搜索
        filteredArticles: function () {
            var articles_array = this. recommendlist,
                searchString = this.searchString;

            if(!searchString){
                return articles_array;
            }

            searchString = searchString.trim().toLowerCase();

            articles_array = articles_array.filter(function(item){
                if(item.id.toLowerCase().indexOf(searchString) !== -1){
                    return item;
                }
            })

            // 返回过来后的数组
            return articles_array;;
        }
    }
  
  // methods:{
  //   go(){
  //     setInterval(()=>{
  //       this.num++;
  //       if(this.num==this.slidelist.length){this.num=0;}
  //     },2000)
  //   }
  // },
  // mounted(){
  //   this.go()
  // }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

.home-content .home-top-ground{
  width:100%;
  height:0px;
  background: linear-gradient(0deg,rgb(68, 148, 68),#84a378 80%);
  /* 方向渐变 */
  border-bottom-left-radius:30px;
  border-bottom-right-radius:30px;
  position:absolute;
  z-index:-1;

}
.home-content .home_nav{
  position:fixed;
  top:0;
  width:100%;
  display:flex;
  justify-content:space-around;
  align-items: center;
  background:#84a378;
  padding:10px;
  color:#fff;
}
.home-content .home_nav .home-search{
  width:55%;
  border:1px solid #000;
  height:30px;
  border-radius: 20px;
}
.home-search{
 color:black;
}
.list{
  padding-top:40px;
}
.item{
  border-bottom:0px dashed #ccc;
  padding:10px;
}
.item-l{
  float:left;
  font-size:0;
  width:40%;
  height:50%;
}
.item-r{
  float:left;
  padding-left:40px;
  width:60%;
  height:50%;
}
.item-img{
  width:98%;
  height:98%;
  border:1px solid #ccc;
}
.item-title{
  font-size:20px;
  margin-top:10px;
  height:80px;
}
.item-title .item-p{
  margin-top:10px;
  font-size:20px;
  color:#000;

}
.item-price{
  margin-top:10px;
  padding-left:100px;
  color:#f00;
  font-size:20px;
}
.item-opt{
  margin-top:5px;
  text-align:right;
}
.item-opt button{
  border:0;
  background:coral;
  color:#fff;
  padding:4px 5px;
  font-size:20px;
}
.item-total{
  padding-top:5px;
  display:5px;
  flex-direction: row;
  justify-content: space-around;
  justify-items: center;

}
.item-total .total{
  text-align: center;
  padding-left:5px;
  padding-right:20%;
  padding-top: 100px;
  font-size:30px;
  color:red;
}
.item-total button{
  width:60px;
}
.gobutton{
  border:0;
  background:coral;
  color:#fff;
  padding:4px 5px;
  font-size:30px;
}
.item-empty{
  text-align: center;
  margin-top:20px;
  font-size:30px;
}
.recommend-context{
  display:flex;
  flex-wrap:wrap;
  justify-items: center;
  justify-content: center;
}
/* 商品的样式 */
.recommend-content{
  display:flex;
  flex-wrap:wrap;
  justify-items: center;
  justify-content: center;
  padding-bottom: 80px;
  padding-left: 0px;
  margin-top: 5px;
  margin-bottom: 20x;
}
.recommend-content li{
  width:46%;
  flex-direction: column;
  padding:8px 0px;
 
}
.recommend-content li .recommend-top img{
  width:98%;
  height:98%;
 
}
.recommend-content li .recommend-top p{
  width:98%;
  height:98%;
  font-size: 14px;
}
.recommend-content .recommend-details{
  width:98%;
  height:5px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
 
}
.recommend-content .recommend-bottom{
  display: flex;
  height:0px;
  justify-content: space-between;
  padding:5 5px;
  align-items:center;
}
.recommend-content .recommend-bottom .recommend-price{
  font-weight: bold;
  color:red;
  font-size: 15px;
}
.recommend-content .recommend-bottom .recommend-see{
  border:0px solid #000;
  height:18px;
  padding:2px;
  text-align:center;
  font-size:15px;
  font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}

</style>
