<template>

  <div class="list">
     <div class="home-content">
     <div class="home-top-ground"></div>
     <div class="home_nav">
      新白鹿餐厅--外卖单
      <input type="text" class="home-search">
      搜索
    </div>
     </div>
        <div class="item" v-for="item in items" :key="item.id">
                <div class="item-l">
                    <img  class="item-img" :src="item.url"/>

                </div>
                <div class="item-r">
                        <div class="item-title">
                          {{item.title}}
                          <p class="item-p">菜品数量：{{item.num}}</p>
                          <numbox :num="item.num" :id="item.id"></numbox>
                          </div>
                        <div class="item-price">{{item.price | currency}}</div>
                        <div class="item-opt">
                            <button @click="del(item.id)">删除</button>
                        </div>
                </div>
        </div>
        <div class="item-total" v-if="items.length">
          <!-- 不为0就是if  为0就是else -->
          <span class="total">商品总价：{{total|currency}}</span>
          <button class="gobutton" @click="createOrder">结算</button>
        </div>
        <div class="item-empty" v-else>你的外卖单空空如也</div>
    </div>
</template>

<script>
import {mapState,mapActions,mapGetters} from 'vuex';
import numbox from '../Share/numbox.vue';

export default{
  components:{numbox},
  computed:{
    ...mapState({//...是拓展的方法
      items:state=>state.shopcart.items
    }),
    ...mapGetters("shopcart",{total:"totalPrice"})
  },
  filters:{
    currency(value){
      return '¥'+value
    }
  },
  methods:mapActions("shopcart",["del"]),
  methods:{
    createOrder(){
      if(this.$store.state.user.username){
        this.$router.push({name:'order_created'})
      }else{
        this.$router.push({name:'login'})
      }
      //this.$router.push(path:'/order/ordercreated')//路由传值
    },
     del(id){
      this.$store.dispatch("shopcart/del",id)
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

.home-content .home-top-ground{
  width:100%;
  height:0px;
  background: linear-gradient(0deg,rgb(68, 148, 68),#84a378 80%);
  /* 方向渐变 */
  border-bottom-left-radius:30px;
  border-bottom-right-radius:30px;
  position:absolute;
  z-index:-1;

}
.home-content .home_nav{
  position:fixed;
  top:0;
  width:100%;
  display:flex;
  justify-content:space-around;
  align-items: center;
  background:#84a378;
  padding:10px;
  color:rgb(7, 6, 6);
}
.home-content .home_nav .home-search{
  width:55%;
  border:1px solid #000;
  height:30px;
  border-radius: 20px;
}

.list{
  padding-top:40px;
}
.item{
  border-bottom:0px dashed #ccc;
  padding:10px;
}
.item-l{
  float:left;
  font-size:0;
  width:40%;
  height:50%;
}
.item-r{
  float:left;
  padding-left:40px;
  width:60%;
  height:50%;
}
.item-img{
  width:98%;
  height:98%;
  border:1px solid #ccc;
}
.item-title{
  font-size:20px;
  margin-top:10px;
  height:80px;
}
.item-title .item-p{
  margin-top:10px;
  font-size:20px;
  color:#000;

}
.item-price{
  margin-top:10px;
  padding-left:100px;
  color:#f00;
  font-size:20px;
}
.item-opt{
  margin-top:5px;
  text-align:right;
}
.item-opt button{
  border:0;
  background:coral;
  color:#fff;
  padding:4px 5px;
  font-size:20px;
}
.item-total{
  padding-top:5px;
  display:5px;
  flex-direction: row;
  justify-content: space-around;
  justify-items: center;

}
.item-total .total{
  text-align: center;
  padding-left:5px;
  padding-right:20%;
  padding-top: 100px;
  font-size:30px;
  color:red;
}
.item-total button{
  width:60px;
}
.gobutton{
  border:0;
  background:coral;
  color:#fff;
  padding:4px 5px;
  font-size:30px;
}
.item-empty{
  text-align: center;
  margin-top:20px;
  font-size:30px;
}
</style>
