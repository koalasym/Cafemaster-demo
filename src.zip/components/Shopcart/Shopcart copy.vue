<template>
  <div >
    <h2>购物车</h2>
    <p>{{name}}</p>
   
    <button class="botton button-default" @click="sub">-</button>
    <strong>{{count}}</strong>
    <button class="botton button-default" @click="add">+</button>
    <hr>
    <button class="botton button-default" @click="mut">mut</button>
    <button class="botton button-default" @click="act">act</button>
    <hr>
    <p>{{this.$store.getters}}</p>
    <p>{{this.$store.getters.doneTodosCount}}</p>
    <hr>
    <h2>列表查询</h2>
    <input type="text" id="" v-model="id">
    <button @click="search">搜索</button>
    <p>搜索结果:{{this.$store.getters.searchG }}</p>
  </div>
</template>

<script>
//导入映射 使用数据映射,辅助函数状态映射,用于生成计算属性，多个key-value ,key是属性的名字，value是一个箭头函数
import {mapState}from 'vuex'

export default {
  name: 'Shopcart',
  data () {
    return {
      
    }
  },
  computed:mapState({
    name:state=>state.name,
    count:state=>state.count
  }),
  methods:{
    sub(){
      //调用mutations的方法是commit
      this.$store.commit('sub')
    },
    add(){
      this.$store.commit('add')
    },
    mut(){
      this.$store.commit('test')
    },
    act(){
      this.$store.dispatch('test','我是actions中参数')
    },
    search(){
      this.$store.commit('searchM',this.id)
    }
  }
  // computed:{
  //   name(){
  //     return this.$store.state.name
  //   }
  // }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
*{
  margin:0;
  padding:0;
}
h2{
  color:blue;
}
.row{
  height:70px;
  box-sizing:border-box;
  margin-left:32px;
  margin-right:32px;
  padding-top:40px;
  border-bottom:1px solid #888;
}
.input{
  width:100%;
  height:30px;
  border:none;
  font-size:16px;
  line-height:20px;
}
.btn{
  height:50px;
  width:100px;
  margin-left:32px;
  margin-right:32px;
  margin-top:32px;
  background:red;
  line-height:50px;
  color:white;
  font-size:24px;
  text-align: center;
  border-radius: 8px;
  
}
</style>
