<template>
  <div class="content">
    <div class="login" style="position:relative;width:80%;left:6%;margin-top:5%;">
        <i class="glyphicon glyphicon-user" style="font-size: 45px"></i>
        <router-link :to="{path:'/login'}"  tag="span" style="font-size: 30px">登录/注册</router-link>
    </div>
    <div :to="{path:'/login'}"  class="vip" style="
          position: relative;
          width: 96%;
          border-radius: 10px;
          height: 600px;
          background: rgba(236, 211, 129, 0.637);
          margin-top: 20px;
          margin-bottom:10px;
          left: 2%;
        "
      >
      <!-- 将页面上方留有导航条 -->
    <div class="nav"> 会员信息</div>
    <div class="content">
        <!-- 讲主体展示部分分为左中右（小屏时上中下）框架，由one,tow,three三个div包括 -->
        <div class="one">
            <!-- 有默认值 -->
            <input type="text" class="one1" placeholder="         | 请输入旧的密码" padding-left="10px;" ><br>
            <!-- 以空格留有小图标填充的空间 -->
            <input type="text" class="one2" placeholder="         | 请输入新的密码"><br>
            <!-- 设置修改密码按键 -->
            <button class="one3">修改密码</button>
        </div>
        <div class="two">
            <!-- 中间部分插入图片及主题文字 -->
            <div class="two1"><img src="./1.jpg"> </div>
            <div class="text1">哪来的恋爱啊</div>
           
        </div>
        <div class="there">
            <!-- 模块3设置4个按钮 -->
            <div class="there1">
                <span class="there-images1"> </span>
                <span>修改密码</span>
            </div>
            <div class="there1">
                <span class="there-images2"> </span>
                <span>消息</span></button>
                <button>13</button>
            </div>
            <div class="there1">
                <span class="there-images3"> </span>
                <span>设置</span>
            </div>
            <div class="there1">
                <span class="there-images4"> </span>
                <span>退出登录</span>
            </div>

        </div>
    
    </div>


    </div>

     
    
</div>
</template>

<script>
export default {
  name: "my3",
  data() {
    return {    };
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

.content{
 
  display: flex;
  flex-direction: column;
  width:100%;
  height:100%;
}
.one,.two,.there{
		width: 100%;
        display: flex;
        flex-direction: column;
        align-items: center;
	}
    .one{
        order:0;
        background: #FFFFFF;
        height: 200px;
        /* padding-left:10 px; */
        /*placeholder文字距左10px*/
        
    }

	.nav{
		text-align: center;
	}
	.one1{
		width: 90%;
		height:70px;
        margin-top: 20px;
        /* 调整小图标的位置，以确保在框合适的地方，默认正方向是向右向下，负是向左向上 */
		background: url(3.png) no-repeat 2px 5px;

		border: 3px solid #E1DED6
	}
	.one2{
		width: 90%;
		height: 70px;
        /* 调整小图标的位置，以确保在框合适的地方，默认正方向是向右向下，负是向左向上 */
		background:  url(2.png) no-repeat 2px 5px;
		border: 3px solid #E1DED6;
	}
    /* one3涉及修改密码、关注和粉丝三个按键的样式 */
	.one3{width: 100%;
		height: 65px;
		background-color: #f3b275;
		margin-top:-10px;
		color: white;
        cursor:pointer;
	}
	.two1 img{
        margin-top: 5px;
		width: 80%;
		height: 80%;
        border-radius: 30%;


	}
    .two1{
        display: flex;
        justify-content: center;
        align-items: center;
        width: 100%;
        background-color:  #ffffff;


    }
    /* 设置中间部分模块的样式 */
    .two2{
        display: flex;

        width: 100%;
        height: 70px;
        background-color: #ebad74;
        align-items: center;
    }
    .two2 div{
        width: 100%;
        margin-top: 8px;

        text-align: center;
        font-size: 14px;
    }
    .two2-one{
        border-right: 1px solid white;
    }
    /* 设置中间模块主题字体的颜色 */
    .text1{
        font-size: 18px;
        color: red;
        margin-top: -10px;
        width: 100%;
        text-align: center;
        line-height: 40px;
        background-color: #FFFFFF;
    }
    .there1{width: 100%;
        height: 50px;
        background-color: #178a21;
        border: 1px solid rgb(34, 230, 99);
        color: white;
        cursor:pointer;

    }
    .there-images1{
        display: inline-block;

        width:25px;
        margin-top: 10px;
        height: 25px;
        
    }
    .there-images2{
          display: inline-block;

          width:25px;
          margin-top: 10px;
          height: 25px;
         
      }
    .there-images3{
            display: inline-block;
            width:25px;
            margin-top: 10px;
            height: 25px;
            
        }
    .there-images4{
              display: inline-block;
              width:25px;
              margin-top: 10px;
              height: 25px;
              
          }
    .one3:hover{
        background-color: #15753a;
    }
    .there1:hover{
           background-color: #178a21;
       }
       /* 设置按钮样式，包括消息提醒的字体颜色 */
    button{
        margin-top: 15px;
        float: right;
        background-color: #60ee0d;
        border-radius: 5px;
        border: none;
        margin-right: 3px;}
        /* @media screen实现网页布局的自适应:无需插件和手机主题,对移动设备友好,能够适应各种窗口大小。只需在CSS中添加@media screen属性,根据浏览器宽度判断并输出不同的长宽值 */
        /* 增加下述代码后，使最小宽的时候呈现上中下的样式 */
        @media screen and (max-width: 500px) {
        .one,.two,.there{
            width: 100%;
            margin-top: 10px;

        }
    }
        @media only screen and (max-width: 500px) {
             .gridmenu {
             width:100%;
            }

            .gridmain {
             width:100%;
            }

             .gridright {
             width:100%;
            }
        }
</style>
