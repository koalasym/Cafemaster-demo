<template>
  <div class="content">
    <div class="login" style="position:relative;width:80%;left:6%;margin-top:5%;">
        <i class="glyphicon glyphicon-user" style="font-size: 45px"></i>
        <router-link :to="{path:'/login'}"  tag="span" style="font-size: 30px">登录/注册</router-link>
    </div>
    
    <router-link :to="{path:'/login'}"  class="vip" style="
          position: relative;
          width: 96%;
          border-radius: 10px;
          height: 370px;
          background: rgba(236, 211, 129, 0.637);
          margin-top: 20px;
          margin-bottom:10px;
          left: 2%;
        "
      >
       <div>
           <div class="father">
        <!-- 第一部分 -->
        <div class="first">
            <div class="column"></div>
            <div class="column-1"></div>
            <div class="line"></div>
            <div class="line-1"></div>

            <div class="b-outline"></div>
            <div class="b-outline-1"></div>

            <div class="m-outline"></div>
            <div class="m-father">
                <div class="m-outline-1"></div>
            </div>

            <div class="s-outline"></div>
            <div class="s-father">
                <div class="s-outline-1"></div>
            </div>


            <div class="in-square"> </div>
            <div class="out-square"></div>

            <div class="square-outline-father">
                <div class="square-outline-top"></div>
                <div class="square-outline-top-son"></div>
                <div class="square-outline-left"></div>
                <div class="square-outline-left-son"></div>
                <div class="square-outline-obttom"></div>
                <div class="square-outline-obttom-son"></div>
                <div class="square-outline-right"></div>
                <div class="square-outline-right-son"></div>
            </div>
            <div class="zyy-father">
                <div class="zyy">
                    <div>新</div>
                    <div>白</div>
                    <div>鹿</div>
                </div>
            </div>
        </div>

        <!-- 第二部分 -->
        <div class="second">
            <div class="shooting-star">
                <div class="shooting-star-1"></div>
                <div class="shooting-star-2"></div>
                <div class="shooting-star-3"></div>
                <div class="shooting-star-4"></div>
                <div class="shooting-star-5"></div>
                <div class="shooting-star-6"></div>
                <div class="shooting-star-7"></div>
                <div class="shooting-star-8"></div>
            </div>
            <div class="second-infomation">               
                <div class="second-infomation-left"></div>
                <div class="second-infomation-middle"></div>
                <div class="second-infomation-right"></div>
                <div class="second-infomation-line"></div>
                <div class="second-left-text">一键开启</div>
                <div class="second-middle-text">新白鹿</div>
                <div class="second-right-text">餐厅之旅</div>
            </div>
            <div class="second-skill">
                <div class="second-skill-1">特色菜品</div>
                <div class="second-skill-2">价格实惠</div>
                <div class="second-skill-3">色香味美</div>
                <div class="second-skill-4">欢迎再来</div>
            </div>
        </div>
        <!-- 第三部分 -->
        <div class="third">
            <div class="third-please-top"></div>
            <div class="third-please-left"></div>
            <div class="third-please">新白鹿会员</div>
            <div class="third-please-right"></div>
            <div class="third-please-bottom"></div>
        </div>
        <!-- 第四部分 -->
        <div class="fourth">
            <div class="fourth-thanks-1"></div>
            <div class="fourth-thanks-2"></div>
            <div class="fourth-thanks-3"></div>
            <div class="fourth-thanks-4"></div>
            <div class="fourth-chioce">
                <div>一品美味佳肴！</div>
            </div>
            <div class="fourth-thanks">冲！</div>

        </div>

    </div>
       </div>

    </router-link>

      <div class="grid-content" >
        <p style="padding-left:15px;font-size:15px;font-weight:bold">新白鹿周边</p>
      <ul>
        <li v-for="(item, index) in assets" :key="index">
          <div>
            <span
              :style="{ color: item.gridColor }"
              :class="item.gridIcon"
            ></span>
            <p>{{ item.gridName }}</p>
          </div>
        </li>
      </ul>
    </div>
    <!-- <div class="grid-content" >
        <p style="padding-left:15px;font-size:15px;font-weight:bold">我的资产</p>
      <ul>
        <li v-for="(item, index) in functions" :key="index">
          <div>
            <span
              :style="{ color: item.gridColor }"
              :class="item.gridIcon"
            ></span>
            <p>{{ item.gridName }}</p>
          </div>
        </li>
      </ul>
    </div>
    <div class="grid-content" >
        <p style="padding-left:15px;font-size:15px;font-weight:bold">生活服务</p>
      <ul>
        <li v-for="(item, index) in serves" :key="index">
          <div>
            <span
              :style="{ color: item.gridColor }"
              :class="item.gridIcon"
            ></span>
            <p>{{ item.gridName }}</p>
          </div>
        </li>
      </ul>
    </div>

      <div class="grid-content" >
        <p style="padding-left:15px;font-size:15px;font-weight:bold">生活服务</p>
      <ul>
        <li v-for="(item, index) in recommends" :key="index">
          <div>
            <span
              :style="{ color: item.gridColor }"
              :class="item.gridIcon"
            ></span>
            <p>{{ item.gridName }}</p>
          </div>
        </li>
      </ul>
    </div>
    <div style="height:100px;display:block;"></div> -->
</div>
</template>

<script>
//import My from '../My/My.vue'
import'./css/main.css'
import'./css/line-column.css'
import'./css/outline.css'
import'./css/square.css'
import'./css/square-outline.css'
import'./css/shootingStar.css'
import'./css/second/secondInfomation.css'
import'./css/second//secondSkill.css'
import'./css/third/thirdPlease.css'
import'./css/fourth/fourthChioce.css'
export default {
  name: "my2",
  data() {
    return {
    assets:[
    {gridName:"新白鹿官网",gridIcon:"glyphicon glyphicon-phone",gridColor:"rgb(248, 96, 49)"},
    {gridName:"连锁店",gridIcon:"glyphicon glyphicon-flash",gridColor:"rgb(255, 171, 46)"},
    {gridName:"福利中心",gridIcon:"glyphicon glyphicon-piggy-bank",gridColor:"rgb(248, 96, 49)"},
    {gridName:"更多",gridIcon:"glyphicon glyphicon-grain",gridColor:"rgb(255, 171, 46)"}
    ]
    };
  },
  components:{
    //My
  },
  methods:{
    loadComment(listcmt){
      this.listcmt=listcmt;
      
    }
  },
  filters:{
    dateFormat(datestr){
      var dt=new Date();
      var y=dt.getFullYear();
      var m=dt.getMonth()+1;
      var d=dt.getDate();
      var hh=dt.getHours();
      var mm=dt.getMinutes();
      var ss=dt.getSeconds();
      return y+"-"+m+"-"+d+"-"+hh+":"+mm+":"+ss;
    }
  }
};
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.content{
  position:absolute;
  display: flex;
  flex-direction: column;
  width:100%;
  height:auto;
}
.grid-content{
  width:96%;
  position:relative;
  left:2%;
  z-index: 100;
  
  background: rgb(255, 255, 255);
  border-radius: 15px;
  height:auto;
  padding-top: 0px;
}
.grid-content ul{
  display:flex;
  flex-wrap: wrap;
  
  
}
.grid-content ul li{
  width:25%;
  max-height: 25%;
  display:flex;
  justify-content: center;
  padding:-2px 0;
}
.grid-content ul li div{
  text-align: center;
}
.grid-content ul li div span{
  color:#000;
  font-size:27px;
  width: 40px;
  height: 40px;
  line-height: 40px;
  border-radius: 10px;
}

</style>
