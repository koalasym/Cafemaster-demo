<template>
  <div >
    <!-- <h2>我的</h2>
    <p v-show="flag">v-show的显示</p>
    <p v-if="flag">v-if的显示</p>
    v-if:每次都会重新删除或创建元素，有较高的切换性能消耗
    v-show：不会重新进行dom的删除和创建，只是切换display属性值，有较高的初始渲染消耗 -->
    <div>
      <div class="form-group">
          <label for="person1">评论人：</label>
          <input type="text" class="form-control" v-model="name">
      </div>
      <div class="form-group">
          <label for="content1">评论内容：</label>
          <input type="text" class="form-control" v-model="content" @keyup.enter="add">
          <input type="button" value="发表评论" class="btn btn-primary" @click="postComment">
      </div>
      <!-- <input type="button" value="发表评论" class="btn btn-primary" @click="postComment"> -->
    </div>
  </div>
</template>

<script>
export default {
  name: 'my',
  data () {
    return {
      name:"",
      content:""
      //listcmt:[]
    };
  },
  methods:{
    postComment(){
      var coment={id:Date.now(),name:this.name,content:this.content,ctime:new Date()};
      var listcmt=JSON.parse(localStorage.getItem('cmts')||'[]');

      listcmt.unshift(coment);//放到数组里
      sessionStorage.setItem('cmts',JSON.stringify(listcmt))
      // localStorage.setItem('cmts',JSON.stringify(listcmt))
      //给父组件
      this.$emit("func",listcmt);//向父组件传参,函数传参
    }
  },
  directives:{
    focus:{
      inserted:function(el){
        el.focus()
      }
    },
    fontweight:{
      bind:function(el){
        el.style.fontweight="900";
      }
    }
  }

  
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
*{
  margin:0;
  padding:0;
}
h2{
  color:blue;
}
.row{
  height:70px;
  box-sizing:border-box;
  margin-left:32px;
  margin-right:32px;
  padding-top:40px;
  border-bottom:1px solid #888;
}
.input{
  width:100%;
  height:30px;
  border:none;
  font-size:16px;
  line-height:20px;
  float:left;
}
.btn{
  height:50px;
  width:100px;
  margin-left:2px;
  margin-top:2px;
  background:rgb(86, 148, 230);
  line-height:50px;
  color:white;
  font-size:24px;
  text-align: center;
  border-radius: 8px;
  
}
</style>
