<template>
    <div>订单
        {{$store.getters['user/getLoginUserName']}}
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>