<template>
    <div class="details-content">
        <span @click="upPage">返回</span>
        <img src="../../assets/images/home-recommend/16.jpg" alt="">
        <!-- <h1>商品详情页{{params.id}}</h1> -->
        <div class="details-body">
                <img  :src=detailsdata.url />
                <div class="details-body-text">
                    <h4>{{detailsdata.title}}</h4>
                    <div >
                    <p1>
                        {{detailsdata.getrecommendtext}}
                        <!-- 这个商品好 -->
                    </p1>
    
                        <p2>价格：
                            {{detailsdata.price}}
                        </p2>
                        <span @click="add(detailsdata)">添加到外卖单</span>
                        <!-- 过滤器也是一个考点 -->
                                            </div>
                </div> 
                <div class="del" id="delete"><a  href="#" @click="del(item.id)">删除</a></div>
                <div class="share-text">美味正在路上.....</div>
        </div>
    <div class="text-content">
   <my @func="loadComent"></my>
    
   <ul class="list-group">
      <li class="list-group-item" v-for="item in listcmt" :key="item.id">
            <span class="badge">评论人：{{item.name}} &nbsp; {{item.ctime}}  </span>
            {{item.content}}
      </li>
   </ul>
  </div>
    </div>
</template>

<script>
//考试 脚手架的应用 main.js index.js
//import my from '../My/My.vue'
export default {
    data() {
        
        return{
            params:this.$route.params,
            detailsdata: {},
            listcmt:[
       //{id:Date.new(),name:"神秘人",content:"很神秘的",ctime:new Date()},
       // {id:Date.new(),name:"神秘人",content:"很神秘的啦",ctime:new Date()},
       // {id:Date.new(),name:"神秘人",content:"很神秘的哇",ctime:new Date()}
      ]
        };
        
    },
    methods:{
    loadComent(){
      console.log("fine")
      var listcmt=JSON.parse(sessionStorage.getItem('cmts')||'[]');
      this.listcmt=listcmt;
    },
        getDetails(){
            this.$http.post(`/commodityInfo/${this.params.id}`).then((result)=>{
                console.log(result.data.data[0]);
                this.detailsdata = result.data.data[0];
            });
        },
         upPage(){
        this.$router.go(-1);//返回上一个路由
        },
        add(item){
            this.$store.dispatch('shopcart/add',item)
        }
    },
    components:{
    //my
  },
    created(){//生命周期
        this.getDetails();
        this.loadComent();
    },
};
</script>
<style scoped>
.details-content{
  display:flex;
  flex-wrap:wrap;
  justify-items:left;
  justify-content: left;
  margin-top: 0px;
  font-family: "Arial","Microsoft YaHei","黑体","宋体",sans-serif;
}
.details-content span{
  font-weight: bold;
  color:rgb(13, 112, 13);
  font-size: 20px;
  font-family: "Arial","Microsoft YaHei","黑体","宋体",sans-serif;
  padding-top:10px;
  float:right;
  border:5px solid rgb(14, 88, 4);

  }
.details-body{
  width:98%;
  height:98%;
  flex-direction: column;
  margin-left: 4px;
  margin-top: 8px;
  margin-bottom: 0x;
  font-family: "Arial","Microsoft YaHei","黑体","宋体",sans-serif;
}
.details-content .details-body img{
  padding-top: 0%;
  margin-top: 0px;
  width:98%;
  height:98%;
  border:5px solid rgb(14, 88, 4);
}
.details-content .details-body p1{
  width:45%;
  height:40%;
  font-size: 25px;
  color:blue;
  font-family: "Arial","Microsoft YaHei","黑体","宋体",sans-serif;
  margin-top: 0px;
  float:left;
}
.details-content .details-body p2{
  width:55%;
  height:40%;
  font-weight: bold;
  color:red;
  font-size: 25px;
  font-family: "Arial","Microsoft YaHei","黑体","宋体",sans-serif;
  float:left;
}
.details-content .details-body span{
  font-weight: bold;
  color:red;
  font-size: 20px;
  font-family: "Arial","Microsoft YaHei","黑体","宋体",sans-serif;
  padding-top:10px;
  float:right;
  border:5px solid rgb(204, 204, 204);
}
.del{
  font-weight: bold;
  color:red;
  font-size: 20px;
  font-family: "Arial","Microsoft YaHei","黑体","宋体",sans-serif;
  padding-top:50px;
}
.share-text{
  margin-top: 5px;
  width:98%;
  height:98%;
  font-size: 25px;
  color:rgb(13, 190, 93);
  font-family: "Arial","Microsoft YaHei","黑体","宋体",sans-serif;

}
.text-content{
  margin:0;
  padding:0;
}
.text-content h2{
  color:blue;
}
.text-content .row{
  height:70px;
  box-sizing:border-box;
  margin-left:32px;
  margin-right:32px;
  padding-top:40px;
  border-bottom:0px solid #888;
}
.text-content .input{
  width:100%;
  height:30px;
  border:none;
  font-size:16px;
  line-height:20px;
}
.text-content .btn{
  height:50px;
  width:100px;
  margin-left:2px;
  margin-top:2px;
  background:red;
  line-height:50px;
  color:white;
  font-size:24px;
  text-align: center;
  border-radius: 8px;
  
}

</style>