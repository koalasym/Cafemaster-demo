<template>
  <div class="home-content">
    <div class="home-top-ground"></div>
    <div class="home_nav">
      新白鹿餐厅
      <input type="text" class="home-search">
      搜索
    </div>
    
    <!-- 快速分类 -->
    <div class="grid-content">
      <ul>
        <li v-for=" (item,index) in gridlist" :key="index">
          <div>
            <span  :class="item.gridIcon" :style="{background:item.gridColor}"></span>
            <p>{{item.gridName}}</p>
          </div>
        </li><!--单项数据绑定 -->
      </ul>
    </div>
    <!-- 轮播图 -->
    <!-- <div class="slide-content">
       <div class="slade-view">
          "../../assets/images/img1.jpg"
         <img v-for="(item,index) in slidelist"  :src= "item" :key="index" alt=""  v-show="num===index"> -->
      <!-- </div>
    </div>  -->
    <div class="firstbutton">
      <i class="glyphicon glyphicon-cutlery" style="font-size: 45px"></i>
      <router-link :to="{path:'/firstpage'}"  tag="span" style="font-size: 30px;">开始点餐</router-link>
    </div>
    <slide :slidelist="slidelist">
      <!-- 父组件如何向子组件传值 -->
      <!-- 1.绑定父组件中的数据到子组件之中 -->
      </slide>
      <!-- 4.商品推荐列表 -->

      <!-- <div>
        <div class="recommend-content">
            <item v-for="(item ,index)in recommendlist" :key="index" :data="item"></item>
        </div>
      </div> -->

      <!-- <img :src="item.url" alt=""> -->
      <!-- <img :src="require('@/assets/images/home-recommend/'+" -->
    
  </div>
</template>

<script>
import Slide from "../Share/Slide.vue"//往上回退上一级..
import item from "../Share/item.vue"
export default {
  name: 'home',
  data () {
    return {
      id:0,
      name:'pokemon',
      gridlist:[
        {gridName:"限时优惠",gridIcon:"glyphicon glyphicon-heart",gridUrl:"",gridColor:"#9986C2"},
        {gridName:"会员权益",gridIcon:"glyphicon glyphicon-ok",gridUrl:"",gridColor:"#BDACDB"},
        {gridName:"五星好评",gridIcon:"glyphicon glyphicon-star-empty",gridUrl:"",gridColor:"#CBACD9"},
        {gridName:"一键注册",gridIcon:"glyphicon glyphicon-tags",gridUrl:"",gridColor:"#8A7BAB"},
        {gridName:"厨房一天",gridIcon:"glyphicon glyphicon-film",gridUrl:"",gridColor:"#C79FD3"},
        {gridName:"宣传片段",gridIcon:"glyphicon glyphicon-play-circle",gridUrl:"",gridColor:"#CFB4D6"},
        {gridName:"新人礼包",gridIcon:"glyphicon glyphicon-lock",gridUrl:"",gridColor:"#9F8FB0"},
        {gridName:"关于我们",gridIcon:"glyphicon glyphicon-home",gridUrl:"",gridColor:"#D78AA0"},
        {gridName:"设置中心",gridIcon:"glyphicon glyphicon-cog",gridUrl:"",gridColor:"#9F8FB0"},
        {gridName:"更多概况",gridIcon:"glyphicon glyphicon-share",gridUrl:"",gridColor:"#FFC0CD"}
      
      ],
      slidelist:[
        require("../../assets/images/1.jpg"),
        require("../../assets/images/2.jpg"),
        require("../../assets/images/3.jpg"),
        require("../../assets/images/4.jpg"),
        require("../../assets/images/5.jpg")
       ],
      num:0//错在这里
    }
  },
  components:{
    Slide,item//导入组件，引入子组件的第二步：注册
  },
  methods:{
    getRecommendData(){
      this.$http.post("/getRecommend").then(result=>{
        console.log(result.data.data);//查看是否拿到数据
        this.recommendlist=result.data.data;
      });//then返回服务器端拿到的结果
    },
    getrecommenddb(){
      this.$http.post("http://localhost:8080/myDemos/getRecommend").then(result=>{
        //console.log(result.data);
        this.recommendlist=result.data; 
      });
    },
    getrecommenddbparam(){//前端向后端传参
        this.$http.post("http://localhost:8080/myDemos/getRecommend",{params:{id:12345,name:'zhangsan'}}).then(result=>{
        //console.log(result.data);
        this.recommendlist=result.data;
      });
    }
    },
    created(){
      this.getRecommendData();
      //this.getrecommenddb();
    }
  
  // methods:{
  //   go(){
  //     setInterval(()=>{
  //       this.num++;
  //       if(this.num==this.slidelist.length){this.num=0;}
  //     },2000)
  //   }
  // },
  // mounted(){
  //   this.go()
  // }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.home-content{
  padding-top:45px;
}
.home-content .home-top-ground{
  width:100%;
  height:200px;
  background: linear-gradient(0deg,rgb(68, 148, 68),#84a378 80%);
  /* 方向渐变 */
  border-bottom-left-radius:30px;
  border-bottom-right-radius:30px;
  position:absolute;
  z-index:-1;

}
.home-content .home_nav{
  position:fixed;
  top:0;
  width:100%;
  display:flex;
  justify-content:space-around;
  align-items: center;
  background:#84a378;
  padding:10px;
  color:#fff;
}
.home-content .home_nav .home-search{
  width:55%;
  border:1px solid #000;
  height:30px;
  border-radius: 20px;
}
.grid-content{
  width:92%;
  position:relative;
  z-index:100;
  margin:15px 4%;
  background: #47885E;
  border-radius:10px;
}
.grid-content ul{
  display:flex;
  flex-wrap:wrap;
}
.grid-content ul li{
  width:20%;
  max-width:20%;
  min-width:20%;
  display:flex;
  justify-content: center;
  padding:8px 0px;
}
.grid-content ul li div{
  text-align: center;
}
.grid-content ul li div span{
  color:#fff;
  font-size:28px;
  width:40px;
  height:40px;
  line-height:40px;
  border-radius:10px;
}
.grid-content p{
  color:#BED3CA;
}
.recommend-context{
  display:flex;
  flex-wrap:wrap;
  justify-items: center;
  justify-content: center;
}
/* 商品的样式 */
.recommend-content{
  display:flex;
  flex-wrap:wrap;
  justify-items: center;
  justify-content: center;
  padding-bottom: 80px;
  padding-left: 0px;
  margin-top: 5px;
  margin-bottom: 20x;
}
.recommend-content li{
  width:46%;
  flex-direction: column;
  padding:8px 0px;
 
}
.recommend-content li .recommend-top img{
  width:98%;
  height:98%;
 
}
.recommend-content li .recommend-top p{
  width:98%;
  height:98%;
  font-size: 14px;
}
.recommend-content .recommend-details{
  width:98%;
  height:5px;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
 
}
.recommend-content .recommend-bottom{
  display: flex;
  height:0px;
  justify-content: space-between;
  padding:5 5px;
  align-items:center;
}
.recommend-content .recommend-bottom .recommend-price{
  font-weight: bold;
  color:red;
  font-size: 15px;
}
.recommend-content .recommend-bottom .recommend-see{
  border:0px solid #000;
  height:18px;
  padding:2px;
  text-align:center;
  font-size:15px;
  font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
}
.firstbutton{
  margin-left:35%;
}
</style>
