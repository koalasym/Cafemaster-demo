<template>
<div style="position:absolute;width:100%;height:auto;">
  <i @click="upPage" class="glyphicon glyphicon-remove" style="color:#888;font-size:30px;left:20px;top:20px;"></i>
  <h1 style="font-weight:bold;font-size:35px;position:relative;top:50px;width:80%;left:10%;">一大波美食正在路上！</h1>
  <div style="position:relative;top:80px;width:80%;left:10%;">
    
<div class="row">
    <input id="username" type="text" placeholder="请输入用户名" value="请输入用户名" class="input" v-model="user.username">
  </div>
  <div class="row">
    <input id="password" type="password" placeholder="请输入密码" class="input" v-model="user.password">
  </div>
            <div>
                
                 <router-link :to="{path:'/my3'}"  tag="a" style="margin-left:55%;">还没有账号?马上注册</router-link>
            </div>
    <div class="btn" @click="login" style="color:black;padding-bottom:55px;">
    登录
    </div>
  </div>
</div>
</template>

<script>
export default {
  name: 'login',
  data () {
    return {
      type:'login',
      user:{
        username:'',
        password:''
      },
      register:{
        username:'',
        password:'',
        passwordconfirm:''
      }
    };
  },
  methods:{
        toregister(){
          if(this.register.username===""||this.register.password===""||this.register.passwordconfirm===""){
            this.$toast("用户名和密码为空")
            this.register.username=this.register.password=this.register.passwordconfirm=""
          }else if(this.register.password!=this.register.passwordconfirm){
            this.$toast("两次输入的密码不一致")
          }else{
          this.$http.get("http://localhost:8080/myDemos/getloginvue",{params:{str1:this.register.username,str2:this.register.password}}).then(result=>{
            console.log(result.data)
            if(result.data==''&& this.register.password==this.register.passwordconfirm){
              this.$toast("注册成功")
              this.$router.go(-1)
            }else{
              if(this.register.password!=this.register.passwordconfirm)
              this.$toast("两次输入的密码不一样")
              else
              this.$toast("用户已注册")
            }
          }).catch(error=>{
            this.$toast("注册失败"+error)
          })//then接收传回来的数据
        }
      },
      changeregister(){
        this.type='register'
      },
      login(){
          if(this.user.username===""||this.user.password===""){
            this.$toast("用户名和密码为空")
            this.user.username=this.user.password=""
          }else{
          this.$http.get("http://localhost:8080/myDemos/getloginvue",{params:{str:this.user.username}}).then(result=>{
            console.log(result.data[0])
            if(result.data[0].password===this.user.password){
              this.$store.dispatch("user/getLogin",result.data[0])
              this.$auth.setAuthorization(this.user.username)
              this.$toast("登陆成功")
              this.$router.go(-1)
            }else{
              this.$toast("用户名或者密码错误")
            }
          }).catch(error=>{
            this.$toast("登陆失败"+error)
          })//then接收传回来的数据
        }
      },
      upPage() {
      this.$router.go(-1);
    },
  },
  created(){
    this.login()
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
*{
  margin:0;
  padding:0;
}
h2{
  color:blue;
}
.row{
  height:70px;
  box-sizing:border-box;
  margin-left:32px;
  margin-right:32px;
  padding-top:40px;
  border-bottom:1px solid #888;
}
.input{
  width:100%;
  height:30px;
  border:none;
  font-size:16px;
  line-height:20px;
}
.btn{
  height:50px;
  width:100px;
  margin-left:32px;
  margin-right:32px;
  margin-top:32px;
  background:#BCC8AF;
  line-height:50px;
  color:white;
  font-size:24px;
  text-align: center;
  border-radius: 8px;

}
h2{
  color:blue;
}
.btn{
  height:50px;
  width:90%;
  margin-left:12px;
  margin-right:32px;
  margin-top:32px;
  background:#15cc4c;
  line-height:50px;
  color:white;
  font-size:24px;
  text-align: center;
  border-radius: 25px;

}
</style>
