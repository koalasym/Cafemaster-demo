<template>
  <div>
    <el-row >
      <el-col  >
        <div class="grid-content bg-purple"></div>
      </el-col>
    </el-row>
    <el-row >
      <el-col  >
        <el-header style=" font-size: 12px;position: relative;">
          <div class="header df-fr-ac">
            <!-- <img :src="url2"/> -->
            新白鹿餐厅</div>
          <el-dropdown style="position: absolute;right: 0;margin-right: 20px;">
            <i class="el-icon-setting" style="text-align: center;color: #ffffff;font-size: 20px;line-height: 60px;"></i>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>查看</el-dropdown-item>
              <el-dropdown-item>新增</el-dropdown-item>
              <el-dropdown-item>删除</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>
        </el-header>
        <el-container style="height: 98%; border: 1px solid #eee">

          <el-aside width="22%" style="background-color: rgb(238, 241, 246)">
            <el-menu default-active="1" active-text-color="#E56A5B">
              <!-- 控制菜单栏默认开启的 -->
              <el-menu-item index="1" @click="selectmenu(1)">主厨推荐<i class="el-icon-arrow-right" style="margin-left: 0px;"></i></el-menu-item>
              <el-menu-item index="2" @click="selectmenu(2)">主菜<i class="el-icon-arrow-right" style="margin-left: 7px;"></i></el-menu-item>
              <el-menu-item index="3" @click="selectmenu(3)">主食<i class="el-icon-arrow-right" style="margin-left: 7px;"></i></el-menu-item>
              <el-menu-item index="4" @click="selectmenu(4)">海鲜<i class="el-icon-arrow-right" style="margin-left: 7px;"></i></el-menu-item>
              <el-menu-item index="5" @click="selectmenu(5)">甜品<i class="el-icon-arrow-right" style="margin-left: 7px;"></i></el-menu-item>
            </el-menu>

            <el-header style="justify-content: center;height: 40px;">
              已点菜
            </el-header>
            <div class="asidbox df-fc-ac">
              <div class="list" v-for="(item,index1) in orderlist" :key="index1">
                <div><span style="margin-right: 5px;">{{index1+1}}</span>{{item.name}}</div>
                <div class="df-frr-ac" style="margin-top: 3px;"><i class="el-icon-edit" style="color: #E56A5B;"></i>
                <input type="text" class="tipsinput" v-model="item.tips" maxlength="12"/>
                <span style="color: #999999;margin-right: 3px;">备注:</span></div>
                <div class="df-fr-ac" style="height: 20px;">
                  <span style="color: #555555;width: 20px;">￥{{item.total}}</span>
                  <div class="colbutton df-fc-ac-jc hand" @click="reduceorder(index1)"><i class="el-icon-minus"></i></div><span class="df-fr-ac-jc"
                    style="width: 60px;">×{{item.quantity}}</span>
                  <div class="colbutton df-fc-ac-jc hand" @click="addorder(index1)"><i class="el-icon-plus"></i></div>
                </div>
              </div>
              <div v-show="shownull" class="show df-fc-ac-jc">还未点菜哦</div>


              <!-- 已点列表 -->
              <div class="asidbottom df-fc">
                <div class="bottomtop df-fr-ac" style="margin: 1px;">
                  <div style="width: 230px;margin-left: 1px;">共<span style="color: #E56A5B;margin: 0 5px;font-size: 20px;">{{sum}}</span>份</div> <br><br>
                    <div class="bottomright"><br>合计： 
                    <span style="color: #E56A5B;font-size: 20px;">￥{{totalprice}}</span>
                    </div>
                </div>
                <div class="df-fc-ac" style="width: 100%;margin-top: 5px;">
                  <div style="background-color: #E56A5B;color: #FFFFFF;height: 35px;width: 200px;border-radius: 10px;"
                    class="df-fc-ac-jc hand" @click="goToplaceorder">
                    下单
                  </div>
                </div>
              </div>
            </div>
          </el-aside>

          <!-- 菜单列表 -->
          <el-container>
            <el-header style="width: 100%;height: 5%;background-color: #FFFFFF;color: #000000;">
              <div class="titlehead"></div><span>{{title}}</span>
            </el-header>
            <el-main style="background-color: #f2f2f2;flex-wrap:wrap;" class="df-fr">
              <List :list="list" @addorderlist="addorderlist"></List>
            </el-main>
          </el-container>


        </el-container>
      </el-col>

    </el-row>

  </div>
</template>

<script>
  import List from "@/components/Meal/list.vue"
  import axios from 'axios'
  export default {
    name: 'firstpage',
    components:{
      List
    },
    data() {
      return {
        title: "主厨推荐",
        orderlist:[],
        list: [],
        menu:{},
        meallist:[
     
       ],
      }
    },
    created() {
      axios.get('./static/menu.json').then(response => {
      	this.list = response.data.first;
        this.menu = response.data;
      }).catch(function(error) {
      	console.log("失败");
      })

      var list=JSON.parse(localStorage.getItem("orderlist"));
      if(list == null){
        this.orderlist=[]
      }else{
        this.orderlist=list
      }
    },
    computed:{
      sum(){
        var sum=0;
        for(var i=0;i<this.orderlist.length;i++){
          sum+=this.orderlist[i].quantity;
        }
        return sum;
      },
      totalprice(){
        var total=0;
        for(var i=0;i<this.orderlist.length;i++){
          total+=this.orderlist[i].total;
        }
        return total;
      },
      shownull(){
        if(this.orderlist.length==0){
          return true;
        }else{
          return false;
        }
      }
    },
    methods:{
      addorderlist(index){
        for(var i=0;i<this.orderlist.length;i++){
          if(this.list[index].id==this.orderlist[i].id){
            this.orderlist[i].quantity++;
            this.orderlist[i].total=this.orderlist[i].quantity*this.orderlist[i].price
            this.orderlist.splice(i,1);
            break;
          }
        }
        this.orderlist.push(this.list[index]);
        localStorage.setItem("orderlist", JSON.stringify(this.orderlist))

      },
      reduceorder(index1){
        if(this.orderlist[index1].quantity<=1){
          this.orderlist.splice(index1,1)
          localStorage.setItem("orderlist", JSON.stringify(this.orderlist))
        }else{
          this.orderlist[index1].quantity--;
          this.orderlist[index1].total=this.orderlist[index1].quantity*this.orderlist[index1].price
        }

      },
      addorder(index1){
        this.orderlist[index1].quantity++;
        this.orderlist[index1].total=this.orderlist[index1].quantity*this.orderlist[index1].price
      },
      selectmenu(id){
        switch(id){
          case 1:
          this.title="主厨推荐";
          this.list=this.menu.first;
          break;
          case 2:
          this.title="主菜";
          this.list=this.menu.second;
          break;
          case 3:
          this.title="主食";
          this.list=this.menu.third;
          break;
          case 4:
          this.title="海鲜";
          this.list=this.menu.fourth;
          break;
          case 5:
          this.title="沙拉";
          this.list=this.menu.fifth;
          break;
        }
      },
      goToplaceorder(){
        this.$router.push({name:'placeorder',params:{list:this.orderlist}})
      },
      showdialog(index1){
        this.dialogVisible = true
      }
    }
  };
</script>

<style>
  .el-row {
    margin-bottom: 0px;

    /* &:last-child {
      margin-bottom: 0;
    } */
  }

  .el-col {
    border-radius: 4px;
  }

  .bg-purple-dark {
    background: #FFFFFF;
  }

  .bg-purple {
    background: #FFFFFF;
  }

  .bg-purple-light {
    background: #FFFFFF;
  }

  .grid-content {
    border-radius: 4px;
    min-height: 2px;
  }

  .row-bg {
    padding: 10px 0;
    background-color: #FFFFFF;
  }

  .el-header {
    background-color: #6DA193;
    display: flex;
    flex-direction: row;
    align-items: center;
    color: #ffffff;
  }
  .header{
    font-size: 20px;
  }
  .header img{
    width: 30px;
    margin-right: 10px;
  }
  .el-aside {
    color: #333;
    background-color: #FFFFFF;
    position: relative;
  }

  .titlehead {
    background-color: #6DA193;
    width: 3px;
    height: 40%;
    margin-right: 10px;

  }

 .show{
   height: 100%;
   color: #666666;
   font-size: 14px;
   font-weight: bold;
 }
 .show img{
   width: 100px;
   margin-bottom: 10px;
 }

  .tipsinput{
    border-bottom: 1px solid #E6E6E6;
    border-top: 0;
    border-left: 0;
    border-right: 0;
  }
  .asidbox {
    width: 100%;
    height: 80%;
    background-color: #FFFFFF;
    overflow-y: auto;
  }
  .asidbox::-webkit-scrollbar{
    display: none;
  }

  .asidbottom {
    background-color: #FFFFFF;
    border-top: 1px solid #f2f2f2;
    width: 95%;
    height: 10%;
    position: absolute;
    bottom: 0;
  }
  .bottomtop{
    position: relative;
  }
  .bottomright{
    position: absolute;
    right: 0;
  }
  .list {
    width: 100%;
    height: 200px;
    border-bottom: 1px solid #F2F2F2;
    padding-top: 10px;
  }

  .colbutton {
    background-color: #6DA193;
    width: 20%;
    height: 20%;
    border-radius: 50%;
    color: #FFFFFF;
  }
</style>
