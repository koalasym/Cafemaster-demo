<template>
  <div>
  <el-row >
      <el-col >
        <div class="grid-content bg-purple"></div>
      </el-col>
    </el-row>
    <el-row>
      <el-col >
        <el-container style="height: 700px; border: 1px solid #eee">
          <el-header style="font-size: 18px;"><el-page-header @back="goBack" content=""></el-page-header>订单详情</el-header>
          <el-main>
            <el-table :data="list">
              <el-table-column prop="id" label="编号" width="100">
              </el-table-column>
              <el-table-column prop="name" label="菜名" width="180">
              </el-table-column>
              <el-table-column prop="quantity" label="数量" width="100">
              </el-table-column>
              <el-table-column prop="price" label="价格" width="100">
              </el-table-column>
              <el-table-column prop="total" label="总价" width="100">
              </el-table-column>
              <el-table-column prop="tips" label="备注" >
              </el-table-column>
            </el-table>
            <div class="totaldetail df-frr-ac"><span>总计：{{totalprice}}元</span><span>就餐人数：{{pnumber}}</span><span>餐桌号：{{tableid}}</span></div>
          </el-main>

          <!-- 底部 -->
          <el-footer>
            <div class="button df-fc-ac-jc hand" @click="generateorder()">
              下单
            </div>
            <div class="button df-fc-ac-jc hand" @click="dialogFormVisible = true">
              餐桌号
            </div>
            <div class="footer df-fr-ac">
              <span style="margin-right: 10px;">就餐人数</span>
              <el-tooltip :disabled="changerdisabled" content="不能再少人了" placement="top" effect="light">
                <div class="colbutton df-fc-ac-jc hand" @click="reducenum()"><i class="el-icon-minus"></i></div>
              </el-tooltip>
                <input type="text" v-model="pnumber" onkeyup="this.value=this.value.replace(/\D/g,'')"/>
              <el-tooltip :disabled="changeadisabled" content="不能再多人了" placement="top" effect="light">
                <div class="colbutton df-fc-ac-jc hand" @click="addnum()"><i class="el-icon-plus"></i></div>
              </el-tooltip>
            </div>
          </el-footer>

          <!-- 弹出对话框 -->
          <el-dialog title="选择餐桌" :visible.sync="dialogFormVisible">
            <div>餐桌号：<input type="text" v-model="tableid"/></div>
            <div slot="footer" class="dialog-footer">
              <el-button @click="dialogFormVisible = false">取 消</el-button>
              <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
            </div>
          </el-dialog>


        </el-container>

      </el-col>

    </el-row>
  </div>
</template>

<script>
export default{
		name:"placeorder",
		props:['myprop'],
    data(){
      return{
        list:[],
        pnumber:3,
        tableid:"",
        rdisabled: true,
        adisabled: true,
        dialogVisible: false,
        dialogFormVisible: false
        }
    },
    created() {
      this.list = this.$route.params.list;
      localStorage.setItem("orderlist", JSON.stringify(this.list))
    },
    computed:{
      changerdisabled(){
        if(this.pnumber>1){
          return true;
        }else{
          return false
        }
      },
      changeadisabled(){
        if(this.pnumber<12){
          return true;
        }else{
          return false
        }
      },
      totalprice(){
        var total=0;
        for(var i=0;i<this.list.length;i++){
          total+=this.list[i].total;
        }
        return total;
      },
    },
		methods:{
      goBack(){
        this.$router.push({name:'firstpage'})
      },
      reducenum(){
        if(this.pnumber>1){
          this.pnumber--;
        }else{
          this.disabled=false;
        }

      },
      addnum(){
        if(this.pnumber<12){
          this.pnumber++;
        }else{
          this.disabled=false;
        }
      },
      goto(){
        this.$router.push({name:'list'})
      },
      generateorder(){
        if(this.list.length==0){
          this.$notify({
            title: '警告',
            message: '还未点餐！',
            type: 'warning'
          });
        }else if(this.tableid==""){
          this.$notify({
            title: '警告',
            message: '还未输入餐桌号！',
            type: 'warning'
          });
        }else{
          this.$notify({
            title: '成功',
            message: '下单完成！',
            type: 'success'
          });
          localStorage.setItem("orderlist", []);
          this.$router.push({name:'firstpage'})
        }
      }
		}
	}
</script>

<style>

  .el-footer{
    background-color: #FFFFFF;
    display: flex;
    flex-direction: row-reverse;
    align-items: center;
    color: #333333;
    border-top: 1px solid #eee;
    padding-bottom: 200px;
  }
  .button{
    background-color: #E56A5B;color: #FFFFFF;height: 35px;width: 100px;border-radius: 10px;margin-left: 20px;
  }
  .footer input{
    width: 50px;
    height: 30px;
    text-align: center;
    margin: 0 10px;
  }
  .totaldetail{
    color: #666666;
    height: 50px;
  }
  .totaldetail span{
    margin-left: 20px;
  }
  .colbutton {
    padding-top: 10px;
  }
</style>
