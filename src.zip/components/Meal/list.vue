<template>
  <div>
  <el-main style="background-color: #f2f2f2;flex-wrap:wrap;" class="df-fr">
    <div class="catebox df-fc" v-for="(item,index) in list" :key="index" >
      <img :src="item.img" @click.stop="showdetail(index)" class="hand"/>
      <span style="height: 50px;">{{item.name}}</span>
      <div class="boxbottom df-fr-ac">
        <span >￥{{item.price}}/份</span>
        <div style="background-color: #E56A5B;color: #FFFFFF;height: 28px;width: 75px;border-radius: 15px;"
          class="right df-fr-ac-jc hand" @click="addorderlist(index)">
          添加
          <i class="el-icon-plus" style="padding-left: 5px;"></i>
        </div>
      </div>
    </div>
  </el-main>
  <!-- 弹出对话框 -->
  <el-dialog title="菜品详情" :visible.sync="dialogVisible">
    <div class="detaildiv df-fr">
      <div class="detailimg">
      <img :src="catedetail.img">
      <span class="span1">{{catedetail.name}}</span>
      <span class="span2">简介：<br/>{{catedetail.introduce}}</span>
      <span class="span3">主要食材：<br/>{{catedetail.material}}</span>
      </div>
      <div class="dialogright df-fc">
        
        
      </div>
    </div>

  </el-dialog>
  </div>
</template>

<script>
export default {
  name:"list",
  props:[
    'list'
  ],
  data () {
    return {
      catedetail:"",
      dialogVisible:false
    }
  },

  methods: {
    addorderlist(index){
      this.$emit("addorderlist",index)
    },
    showdetail(index){
      this.catedetail=this.list[index]
      this.dialogVisible=true
    }
  }
};
</script>


<style>
  .catebox {
    width: 290px;
    height: 370px;
    background-color: #FFFFFF;
    border-radius: 15px;
    margin-right: 20px;
    margin-bottom: 20px;
    box-shadow: 0 10px 10px #e6e6e6;
  }

  .catebox img {
    padding-left: 18px;
    width: 270px;
  }

  .catebox span {
    margin: 10px;
    color: #333333;
  }
  .boxbottom{
    position: relative;
  }
  .boxbottom .right{
    position: absolute;
    right: 10px;
  }
  .dialogright{
    width:300px;
    height:500px;
  }
    .detaildiv{
    width:300px;
    height:500px;
  }
  .dialogright .span1{
    font-size: 20px;
      width:20%;
    height:50%;
  }
  .dialogright .span2{
      width:20%;
    height:50%;
  }
.detailimg{
   padding-left: 18px;
    width: 300px;
}
</style>
