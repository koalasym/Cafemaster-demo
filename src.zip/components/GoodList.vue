<template>
    <div class="list">
        <div class="item" v-for="goods in goodslist" :key="goods.id">
                <div class="item-l">
                    <img class="item-img" :src="goods.url" />

                </div>
                <div class="item-r">
                        <div class="item-title">{{goods.titletext}}</div>
                        <div class="item-price">{{goods.price | currency}}</div>
                        <!-- |这个是过滤器设置样式的 -->
                        <div class="item-opt">
                            <button @click="add(goods)">加入购物车</button>
                        </div>
                </div>
        </div>

    </div>
</template>
<script>
import { mapState,mapActions } from 'vuex';
//现在要数据获取，映射goodlist
export default {//6个生命周期函数要复习
    data(){
        return{
            //console.log(goodlist);
            id:"",
        };
    },
    methods:mapActions("shopcart",["add"]),//把add映射到shopcart
        
    computed:mapState({//用计算函数映射，created执行完毕后，那边封装的state的list已经有值了，把state封装的goods的list映射出来
        goodslist:state=>state.goods.list
    }),
    created(){
        
        this.$store.dispatch("goods/getList");
    },
    filters:{
        currency(value){
            return '¥'+value
        }
    }
}
</script>
<style scoped>
.list{
  padding-top:5px;
  border-bottom:0px dashed #ccc;
}
.item{
  border-bottom:0px dashed #ccc;
  padding:10px;
  padding-top:5px;
}
.item-l{
    float:left;
    padding-left:5px;
    padding-top:5px;
    border-bottom:1px dashed #ccc;
}
.item-r{
    float:left;
    padding-left:5px;
    width:150px;
    padding-bottom:27px;
    border-bottom:1px dashed #ccc;
}
.item-img{
    width:80%;
    height:80%;
    border:0px solid #ccc;
    border-bottom:0px dashed #ccc;
    padding-bottom:5px;
}
.item-title{
    font-size:14px;
    margin-top:20px;
}
.item-price{
    margin-top:10px;
    color:#f00;
    font-size:15px;
}
.item-opt{
    margin-top:10px;
}
.item-opt button{
    border:0;
    background:coral;
    color:#fff;
    padding:4px 5px;
    cursor:pointer;
}
</style>