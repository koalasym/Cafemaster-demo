<template>
  <div >
   
    <h2>请选择登陆方式</h2>
    <button @click="loginType='username'">用户名</button>
    <button  @click="loginType='email'">email</button>
    <div class="form-group">
      <div v-if="loginType==='username'"><!-- 上面是true下面就是false-->
        <label for="username1">username</label>
        <input type="text" placeholder="enter your username" key="username-input" class="form-control">
      </div>
       <div v-if="loginType==='email'">
        <label for="email1">email</label>
        <input type="text" placeholder="enter your email" key="username-input" class="form-control">
      </div>
    </div>
            <!-- <div id="app">
          <div id="todo-list-example">
          <form v-on:submit.prevent="addNewTodo">
            <label for="new-todo">添加 todo</label>
            <input
              v-model="newTodoText"
              id="new-todo"
              placeholder="例如：明天早上跑步"
            />
            <button>添加</button>
          </form>
          <ul>
            <todo-item
              v-for="(todo, index) in todos"
              :key="todo.id"
              :title="todo.title"
              @remove="todos.splice(index, 1)"
            ></todo-item>
          </ul>
        </div>
          </div> -->
  </div>


</template>

<script>
//import simple_counter from "../Share/simple_counter.vue"
export default {
  name: 'classify',
  data () {
     return {
      newTodoText: '',
      todos: [
        {
          id: 1,
          title: '看电影'
        },
        {
          id: 2,
          title: '吃饭'
        },
        {
          id: 3,
          title: '上 RUNOOB 学习'
        },
      ],
      nextTodoId: 4,
      loginType:""
    }
  },
   methods: {
    addNewTodo() {
      this.todos.push({
        id: this.nextTodoId++,
        title: this.newTodoText
      })
      this.newTodoText = ''
    }
  },
  // components:{
  //     simple_counter//导入组件，引入子组件的第二步：注册
  // },


}

</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
*{
  margin:0;
  padding:0;
}
h2{
  color:blue;
}
.row{
  height:70px;
  box-sizing:border-box;
  margin-left:32px;
  margin-right:32px;
  padding-top:40px;
  border-bottom:1px solid #888;
}
.input{
  width:100%;
  height:30px;
  border:none;
  font-size:16px;
  line-height:20px;
}
.btn{
  height:50px;
  width:100px;
  margin-left:32px;
  margin-right:32px;
  margin-top:32px;
  background:red;
  line-height:50px;
  color:white;
  font-size:24px;
  text-align: center;
  border-radius: 8px;
  
}
</style>
