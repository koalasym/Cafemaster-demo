import Vue from 'vue'
import Vuex from 'vuex'

import goods from './module/goods'
import shopcart from './module/shopcart'
import user from './module/user'

Vue.use(Vuex)//在当前环境中安装环境

export default new Vuex.Store({
    //state类似data
    state:{
        name:'store中的数据',
        count:1,
        name:'张三',
        age:38,
        gender:'男',
        todos:[
            {id:1,text:'完成',done:true},
            {id:2,text:'未完成',done:false}
        ],
        id:0
    },
    //mutations更改state中的数据,类似于methods，跟踪到state中数据的变化
    mutations:{
        increase(state){//形参state
            state.count++
        },
        sub(state){
            if(state.count!=0)
            {state.count--}
        },
        test(state){
            console.log(state)
        },
        searchM(state,id){
            state.id=id
        }
    },
    //处理异步操作,类似于method，调用mutations中的方法
    actions:{
        test(context,param){
            console.log(context)
            console.log(param)
        },
        add(context){
            setTimeout(()=>{
                context.commit('increase')
            },1000)
        },
    },
    //getters类似于计算属性，计算函数
    getters:{
        doneTodos:state=>{
            return state.todos.filter(todo=>todo.done)
        },
        doneTodosCount:(state,getters)=>{
            return getters.doneTodos.length
        },
        searchG:state=>{
            return state.todos.filter(todo=>todo.id==state.id)
        }
    },
    //分模块
    modules:{//封装在module中的两个模块，并分别在各自暴露
        goods,
        shopcart,
        user
    }
})//状态管理器用来管理数据，store包含许多对象
