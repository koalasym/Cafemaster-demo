const state={
    user:null
    //空的就是没有传过值
}
const mutations={
    getLogin(context,data){
        state.user=data
    }
}
const actions={//action调用mutation
  getLogin(context,data){
      context.commit('getLogin',data)
  }
}
const getters={
    getLoginUserName(state){
        return state.user? state.user.username:'未登录'
    }
}
export default{
    namespaced:true,//增加模块名做前缀
    state,
    mutations,
    actions,
    getters
}