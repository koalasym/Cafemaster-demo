import shop from '../../../api/shop'
//goods.js作为商品页面的信息,所有商品的数据获取和封装
const state={
    list:[]//封装用来存储商品的对象
}
const mutations={
    setList(state,data){//接受actions传过来的参数
        state.list=data
    }
}
const actions={//action调用mutation
    getList(context){//把数据传到list里去
        shop.getGoodsList(data=>{
            context.commit('setList',data)
        })
    }
}
const getters={
    
}
export default{
    namespaced:true,//增加模块名做前缀
    state,
    mutations,
    actions,
    getters
}