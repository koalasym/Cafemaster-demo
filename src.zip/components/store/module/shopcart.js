//shopcart页面作为购物车的信息,数据获取和封装
const state={
    items:[]
}
const mutations={
    add(state,goods){
        //从items中查找是否已经存在要购买的商品
        const result=state.items.find(item=>item.id===goods.id)
        if(result){
            alert('加入外卖单成功');
            result.num++;
        }
        else{
            alert('加入外卖单成功');
            state.items.push({
                id:goods.id,
                title:goods.titletext,
                price:goods.price,
                url:goods.url,
                num:1
            })
        }
       
    },
    del(state,id){
        state.items.forEach((item,index,arr)=>{
            if(item.id===id){
                arr.splice(index,1)//删掉一个商品,找一个id相等的
            }
        })
        
    },
    numM(state,good){//接受num
        state.items.forEach((item)=>{
            if(item.id=good.id){
                item.num=good.num
            }
        })
    }
}
const actions={//methods
    add(context,item){
        context.commit('add',item)//调用mutations方法
    },
    del(context,id){
        context.commit('del',id)
    },
    numA(context,good){
        context.commit('numM',good)
    }
}
//reduce 累计求和
const getters={//computed
    totalPrice:(state)=>{
        return state.items.reduce((total,item)=>{
            return total+item.price*item.num
        },0).toFixed(2)
    },
    getCount(state){
            var count=0;
            state.items.forEach((item)=>{
                count+=item.num;
            })
            return count
        }
    
}
export default{
    namespaced:true,//增加模块名做前缀
    state,
    mutations,
    actions,
    getters
}