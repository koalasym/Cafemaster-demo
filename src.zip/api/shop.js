const data=[
    {id:"1",titletext:'小苹果',url:require("../assets/images/home-recommend/1.jpg"),price:4399,getrecommendtext:"这个商品好"},
    {id:"2",titletext:'小太阳',url:require("../assets/images/home-recommend/2.jpg"),price:14399,getrecommendtext:"这个商品好"},
    {id:"3",titletext:'小香蕉',url:require("../assets/images/home-recommend/3.jpg"),price:399,getrecommendtext:"这个商品好"},
    {id:"4",titletext:'小柠檬',url:require("../assets/images/home-recommend/4.jpg"),price:499,getrecommendtext:"这个商品好"},
    {id:"5",titletext:'小葡萄',url:require("../assets/images/home-recommend/5.jpg"),price:439,getrecommendtext:"这个商品好"},
    {id:"6",titletext:'小桃子',url:require("../assets/images/home-recommend/6.jpg"),price:43,getrecommendtext:"这个商品好"},
    {id:"7",titletext:'小橘子',url:require("../assets/images/home-recommend/7.jpg"),price:399,getrecommendtext:"这个商品好"},
    {id:"8",titletext:'小西瓜',url:require("../assets/images/home-recommend/8.jpg"),price:439,getrecommendtext:"这个商品好"},
    {id:"9",titletext:'大苹果',url:require("../assets/images/home-recommend/9.jpg"),price:439,getrecommendtext:"这个商品好"},
    {id:"10",titletext:'大西瓜',url:require("../assets/images/home-recommend/10.jpg"),price:49,getrecommendtext:"这个商品好"}
]

export default{
    getGoodsList(callback){
        //异步形式
        setTimeout(()=>callback(data),100)
        //callback(data)
    }
}